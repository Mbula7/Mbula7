package com.calculadora.calculadoraRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculadoraRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculadoraRestApplication.class, args);
	}

}
