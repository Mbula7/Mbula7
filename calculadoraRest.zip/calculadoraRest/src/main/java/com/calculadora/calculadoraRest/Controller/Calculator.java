package com.calculadora.calculadoraRest.Controller;



import lombok.Data;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController("/calc")
@Data
public class Calculator {

      private Integer valor1 = 5;
      private Integer valor2 = 2;
      private Integer soma = valor1 + valor2;
      private Integer subtracao = valor1-valor2;
      private Integer multiplicacao= valor1 * valor2;
      private Integer divisao = valor1/valor2;

      @GetMapping("/")
      public Integer calc(){
          return getSoma();
      }

      @GetMapping("/sub")
      public Integer sub(){
            return getSubtracao();
      }

      @GetMapping("/mult")
      public Integer mult(){
            return getMultiplicacao();
      }

      @GetMapping("/div")
      public Integer divisao(){
            return getDivisao();
      }

}
